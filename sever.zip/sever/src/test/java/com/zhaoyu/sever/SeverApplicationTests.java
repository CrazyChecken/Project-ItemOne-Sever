package com.zhaoyu.sever;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeverApplicationTests {

	@Test
	void contextLoads() {
	}

}
